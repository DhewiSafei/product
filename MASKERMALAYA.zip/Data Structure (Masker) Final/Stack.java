
public class Stack
{
    LinkedList list;
    public Stack(){list=new LinkedList();}

    public void push(Object element){list.addLast(element);}

    public Object pop(){return list.removeLast();}

    public Object peek(){return list.getLast();}

    public boolean isEmpty(){return list.isEmpty();}
    
    public int size(){return list.size();}

}
