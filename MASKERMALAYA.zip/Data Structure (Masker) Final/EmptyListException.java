
public class EmptyListException extends RuntimeException
{
    // handle exception if the list is null
    public EmptyListException(String name)
    {
        super("The "+name+" is empty");
    }
    
}