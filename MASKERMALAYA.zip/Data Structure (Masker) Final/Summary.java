import java.util.Collections;
import java.util.Comparator;
import java.io.IOException;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.PrintWriter;

public class Summary
{
    LinkedList list;

    //Retrieve list from main class 
    Summary(LinkedList list)
    {
        this.list=list;
    }
    
    //Retrieve all item from the list to display 
    public String FindAll(){
        String item="";
        Object obj=list.getFirst();
        int index=0;
        Masker n;
        while(obj!=null){
            n=(Masker)obj;
            item+=index+++"-"+n.toString()+"<br>";
            obj=list.getNext();
        }
        return item;
    }

     //Retrieve item by name from the list to display 
    public String FindByName(String name){
        String item="";
        Object obj=list.getFirst();
        Masker n;
        while(obj!=null){
            n=(Masker)obj;
            if(name.equalsIgnoreCase(n.getName()))
            {  item+=n.toString()+"<br>";}
            obj=list.getNext();
        }
        return item;
    }

     //Retrieve item by masker code from the list to display 
    public String FindByMaskerCode(String code){
        String item="";
        Object obj=list.getFirst();
        Masker n;
        while(obj!=null){
            n=(Masker)obj;
            if(code.equalsIgnoreCase(n.getMaskerCode()))
            {  item+=n.toString()+"<br>";}
            obj=list.getNext();
        }
        return item;
    }

     //Remove specific item from the list using index
    public void RemoveByIndex(int index){
        list.remove(index);
    }

     //Update specific item from the list using index
    public void UpdateList(int index,Customer masker)
    {
        list.set(index,masker);
    }

     //Calculate total price from the list for specific masker code
    public double CalculateAllPaymentMaskerCode(String code){
        double totalPrice=0.0,mydiscount=0.0;
        Object obj=list.getFirst();
        Masker n;
        while(obj!=null){
            n=(Masker)obj;
            if(code.equalsIgnoreCase(n.getMaskerCode()))
            {   
                totalPrice+=n.Price();
                 mydiscount=n.discount();
            }
            obj=list.getNext();
        }
       return totalPrice-mydiscount;
    }

    //Calculate total price from the list for specific customer name
    public double CalculateAllPaymentByName(String name){
        double totalPrice=0.0,mydiscount=0.0;
        Object obj=list.getFirst();
        Masker n;
        while(obj!=null){
            n=(Masker)obj;
            if(name.equalsIgnoreCase(n.getName()))
            {   
                totalPrice+=n.Price();
                 mydiscount=n.discount();
            }
           
            obj=list.getNext();
        }
        return totalPrice-mydiscount;
    }

    //Calculate total price and average from the list for all item in the list
    public String TotalPriceAndAverage(){
        double totalPrice=0.0;
        int count=0;
        Object obj=list.getFirst();
        Masker n;
        while(obj!=null){
            n=(Masker)obj;
            totalPrice+=n.Price();
            count++;
            obj=list.getNext();
        }

        return "TOTAL ELEMENT IN THE LIST "+count+"<br>TOTAL PAYMENT RECEIVED :RM"+String.format("%.2f", totalPrice)+"<br>TOTAL AVERAGE:"+String.format("%.2f", totalPrice/count);
    }

    //Find Maximum and Minimum sold item by category from the list
    public String MaskerSoldByCategory(){
        String[] code={"A1","A2","B1","B2","C1","C2","D1","D2"};
        
        int max=0;
        String maxItem="";
        for(int i=0;i<code.length;i++){
            if(max<=list.CountMaskerSold(code[i]))
            {
                max=list.CountMaskerSold(code[i]);
                maxItem=code[i];
            }
        }
        
        int min=list.CountMaskerSold(code[0]);
        String minItem="";
        for(int i=0;i<code.length;i++){
            if(min>=list.CountMaskerSold(code[i])&&list.CountMaskerSold(code[i])!=0)
            {
                min=list.CountMaskerSold(code[i]);
                minItem=code[i];
            }
        }
        return "<br><br>HIGHEST MASKER SOLD :"+max+" FOR MASKER CODE "+maxItem+"<br>LOWEST MASKER SOLD :"+min+" FOR MASKER CODE "+minItem;
    }

    //Export all data from the list to notepad by category of masker
    public void ClassificationByCategory()
    {

        Queue listA=new Queue();
        Queue listB=new Queue();
        Queue listC=new Queue();
        Queue listD=new Queue();
        Queue other=new Queue();
        Object obj=list.getFirst();
        Masker n;
        while(obj!=null){
            n=(Masker)obj;
            if(n.getMaskerCode().equalsIgnoreCase("A1"))
                listA.enqueue(n);
            else if(n.getMaskerCode().equalsIgnoreCase("A2"))
                listA.enqueue(n);
            else if(n.getMaskerCode().equalsIgnoreCase("B1"))
                listB.enqueue(n);
            else if(n.getMaskerCode().equalsIgnoreCase("B2"))
                listB.enqueue(n);
            else if(n.getMaskerCode().equalsIgnoreCase("C1"))
                listC.enqueue(n);
            else if(n.getMaskerCode().equalsIgnoreCase("C2"))
                listC.enqueue(n);
            else if(n.getMaskerCode().equalsIgnoreCase("D1"))
                listD.enqueue(n);
            else if(n.getMaskerCode().equalsIgnoreCase("D2"))
                listD.enqueue(n);
            else
                other.enqueue(n);
            obj=list.getNext();
        }

        try  {
            BufferedWriter writeList=new BufferedWriter(new FileWriter("MaskerCustomerA.txt"));        
            PrintWriter printList=new PrintWriter(writeList);

            Object tempObj;
            Masker m;
            while(!listA.isEmpty())
            {
                tempObj=listA.dequeue();
                m=(Masker)tempObj;
                writeList.write(m.getName()+";"+m.getMaskerCode()+";"+m.Price());   
                writeList.newLine();
            }   
            printList.close();
        } catch (IOException e) {System.err.println(e);}

        try  {
            BufferedWriter writeList=new BufferedWriter(new FileWriter("MaskerCustomerB.txt"));        
            PrintWriter printList=new PrintWriter(writeList);

            Object tempObj;
            Masker m;
            while(!listB.isEmpty())
            {
                tempObj=listB.dequeue();
                m=(Masker)tempObj;
                writeList.write(m.getName()+";"+m.getMaskerCode()+";"+m.Price());   
                writeList.newLine();
            }   
            printList.close();
        } catch (IOException e) {System.err.println(e);}

        try  {
            BufferedWriter writeList=new BufferedWriter(new FileWriter("MaskerCustomerC.txt"));        
            PrintWriter printList=new PrintWriter(writeList);

            Object tempObj;
            Masker m;
            while(!listC.isEmpty())
            {
                tempObj=listC.dequeue();
                m=(Masker)tempObj;
                writeList.write(m.getName()+";"+m.getMaskerCode()+";"+m.Price());   
                writeList.newLine();
            }   
            printList.close();
        } catch (IOException e) {System.err.println(e);}

        try  {
            BufferedWriter writeList=new BufferedWriter(new FileWriter("MaskerCustomerOther.txt"));        
            PrintWriter printList=new PrintWriter(writeList);

            Object tempObj;
            Masker m;
            while(!other.isEmpty())
            {
                tempObj=listD.dequeue();
                m=(Masker)tempObj;
                writeList.write(m.getName()+";"+m.getMaskerCode()+";"+m.Price());   
                writeList.newLine();
            }   
            printList.close();
        } catch (IOException e) {System.err.println(e);}

    }

    //Find the highest quantity of masker purchased by customer
    public String FindHighest(){
        Object max=list.MaximumQuantity();
        return ((Masker)max).toString();
    }

    //Find the lowest quantity of masker purchased by customer
    public String FindLowest(){
        Object low=list.MinimumQuantity();
        return ((Masker)low).toString();
    }

    //Sort as Descending the list by Customer name
    public String SortByCustomerNameDescending(){
        list.SortByCustomerNameDescending();
        String item="";
        for (int i = 0; i <  list.size() ; i++) {
            item+=((Masker)list.get(i)).toString()+"<br>";
        }
        return item;
    }

    //Sort as Ascending the list by Customer name
    public String SortByCustomerNameAscending(){
        list.SortByCustomerNameAscending();
        String item="";
        for (int i = 0; i <  list.size() ; i++) {
            item+=((Masker)list.get(i)).toString()+"<br>";
        }

        return item;
    }

    //Sort as Ascending the list by MaskerCode
    public String SortByMaskerPriceAscending(){
        list.SortByPriceAscending();
        String item="";
        for (int i = 0; i <  list.size() ; i++) {
            item+=((Masker)list.get(i)).toString()+"<br>";
        }

        return item;
    }

    //Sort as Descending the list by MaskerCode
    public String SortByMaskerPriceDescending(){
        list.SortByPriceDescending();
        String item="";
        for (int i = 0; i <  list.size() ; i++) {
            item+=((Masker)list.get(i)).toString()+"<br>";
        }

        return item;
    }

}
