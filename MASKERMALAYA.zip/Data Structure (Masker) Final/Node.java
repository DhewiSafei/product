
public class Node
{
    Object data;
    Node next;
    
    //receive object
    Node(Object o)
    {
        this(o,null);
    }

    //set item for current object and next object
    Node(Object o,Node next){
        this.data=o;
        this.next=next;
    }

    //accessor
    Object getData(){return data;}
    Node getNext(){return next;}
    
    //mutator
    void setNext(Node next){ this.next=next;}


}
