
public class Masker extends Customer
{
    String maskerCode;
    int maskerQuantity;
    Category item;
    
    Masker(String name,String maskerCode,int maskerQuantity){
        super(name);
        this.maskerCode=maskerCode;
        this.maskerQuantity=maskerQuantity;
    }

    //accessor
    public String getMaskerCode(){return maskerCode;}
    public void setMaskerCode(String o){maskerCode=o;}
    
    //mutator
    public int getmaskerQuantity(){return maskerQuantity;}
    public void setmaskerQuantity(int o){maskerQuantity=o;}

    // get discount after identify membeship
    public double discount(){
        if(membership())
            return 0.5;
        else
            return 0.0;
    }
    
    //get price based on masker category class
    public double Price(){
        item =new Category(maskerCode);
        return item.getPrice()*maskerQuantity;
    }

    //get description based on masker category class  
    public String Description(){
        item =new Category(maskerCode);
        return item.getDescription();
    }
    
    //get weight based on masker category class
    public double Weight(){
        item =new Category(maskerCode);
        return item.getWeight();
    }

    //output class will return toString
    public String toString(){
        return super.toString()+
               "   MAKSKER CODE :"+maskerCode+
               "   DESCRIPTION :"+Description()+
               "   WEIGHT :"+Weight()+"g"+
               "   QUANTITY :"+maskerQuantity+
               "   PRICE :RM"+String.format("%.2f", Price())+
               "   DISCOUNT :"+discount()+
               " ";
    }

}
