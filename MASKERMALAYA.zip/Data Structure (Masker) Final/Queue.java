
public class Queue
{
    LinkedList list;
    Queue(){list=new LinkedList();}

    //to check the queue is empty or not
    boolean isEmpty(){return list.isEmpty();}
    
    //to identify the queue size
    public int size(){return list.size();}
    
    // mutator for queue based on linkedlist
    public void enqueue(Object element){list.addLast(element);}
    
    //accesor for queue  based on linkedlist
    public Object dequeue(){return list.removeFirst();}
    
    // get the first object form queue
    public Object front(){return list.getFirst();}
    
    //get last object from the queue
    public Object rear(){return list.getLast();}
    
}
