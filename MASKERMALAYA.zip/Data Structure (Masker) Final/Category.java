import java.io.BufferedReader;
import java.io.FileReader;
import java.util.StringTokenizer;
import java.io.IOException;

public class Category
{
    String maskerCode;
    String categoryDescription;
    double price,weight;

    
    Category(String maskerCode)
    {
        this.maskerCode=maskerCode;
    }
    
    // this function is to read from notepad and get the item detail base on masker code
    private void ReadFromTextFiles(){
        try {
            BufferedReader read = new BufferedReader(new FileReader("Masker.txt"));
            String data = read.readLine();
            while(data != null){
                StringTokenizer m = new StringTokenizer(data, ";");
                
                String mCode=m.nextToken();
                String mDescription=m.nextToken();
                String mWeight=m.nextToken();
                String mPrice=m.nextToken();
                double mPriceVal=Double.parseDouble(mPrice);
                double mWeightVal=Double.parseDouble(mWeight);
                
                if(maskerCode.equalsIgnoreCase(mCode))
                {
                    this.categoryDescription=mDescription;
                    this.price=mPriceVal;
                    this.weight=mWeightVal;
                } 
                data = read.readLine();
            }
            read.close();
        }catch (IOException err) {
            System.err.print(err);
        }
    }

    // get the masker descrition from function readTextfile
    public String getDescription(){
        this.ReadFromTextFiles();
        return categoryDescription;
    }

    // get the masker price from function readTextfile
    public double getPrice(){
        this.ReadFromTextFiles();
        return price;
    }
    
    // get the masker weight from function readTextfile
    public double getWeight(){
        this.ReadFromTextFiles();
        return weight;
    }

}
