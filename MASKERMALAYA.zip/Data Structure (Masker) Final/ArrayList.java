import java.util.Arrays;
public class ArrayList
{
       private Object[] myStore;
       private int actSize=0;
       
       ArrayList()
       {
           myStore=new Object[10];
        }
        
        public int size(){return actSize;}
        
        public Object get(int index){
            if(index<actSize)
            return myStore[index];
            else
            throw new ArrayIndexOutOfBoundsException();
        }
        
        public void add(int index,Object obj){
            if(index<actSize)
            {actSize++;
                int ind=actSize;
                while(ind>index){
                    myStore[ind-1]=myStore[ind-2];
                    ind--;
                }
                myStore[index]=obj;
            }
            else
            System.err.print("Out of Boundaries");
        }
        
        public void increaseListSize()
        {
            myStore=Arrays.copyOf(myStore,myStore.length*2);
            System.out.print("\nNew Length"+myStore.length);
        }
        
        public void add(Object obj)
        {
            if(myStore.length-actSize<=5){increaseListSize();}
            myStore[actSize++]=obj;
        }
        
        public Object remove(int index)
        {
            if(index<actSize){
                Object obj=myStore[index];
                myStore[index]=null;
                int tmp=index;
                while(tmp<actSize){
                    myStore[tmp]=myStore[tmp+1];
                    myStore[tmp+1]=null;
                    tmp++;
                }
                actSize--;
                return obj;
            }
            else
                throw new ArrayIndexOutOfBoundsException();
        }
        
        public Object set(int i,Object obj){
            Object dataBeforeUpdate=null;
            if(i<0||i>=myStore.length)
                System.out.print("Index out of range");
            else
            {
                dataBeforeUpdate=myStore[i];
                myStore[i]=obj;
            }
            return dataBeforeUpdate;
        
        }

}
