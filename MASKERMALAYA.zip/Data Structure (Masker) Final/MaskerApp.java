
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javafx.scene.layout.Border;
import java.net.*;

class MaskerMenu implements ActionListener {
    JFrame frame=new JFrame();

    JButton btInsert=new JButton("Insert Record");
    JButton btUpdate=new JButton("Update Record");
    JButton btViewAll=new JButton("View Record");
    JButton btSearchCode=new JButton("Search Code");
    JButton btSearchName=new JButton("Search Name");
    JButton btDelete=new JButton("Delete Record");
    JButton btSortAsc=new JButton("Sort Ascending");
    JButton btSortDsc=new JButton("Sort Descending");
    JButton btAnalysis=new JButton("Analysis Record");
    JButton btSaveTextFile=new JButton("Save to text files");

    JLabel lbTitle=new JLabel("****** WELCOME TO MASKER MALAYA SYSTEM *****");
    JLabel lbDescription=new JLabel("--develop by dhewi--");
    JLabel lbName=new JLabel("Customer Name :");
    JLabel lbCode=new JLabel("Masker Code :");
    JLabel lbQuantity=new JLabel("Quantity :");
    JLabel lbReference=new JLabel("<html>Masker Code :<br>A1:20g A2:30g - APPLE<br>B1:20g  B2:30g - BANANA<br>C1:20g C2:30g - CHERRY<br>D1:20g D2:30g - DAISY</html>");

    JTextField tfName=new JTextField("");
    JTextField tfCode=new JTextField("");
    JTextField tfQuantity=new JTextField("");
    JTextField tfSearch=new JTextField("");

    JLabel output=new JLabel("Output");

    
    MaskerMenu(){
        prepareGUI();
        Properties();
    }

    public void prepareGUI(){
        frame.setTitle("Masker Malaya");
        frame.getContentPane().setLayout(null);
        frame.setVisible(true);
        frame.setBounds(400,400,1000,650);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public void Properties(){
        
         
        btInsert.setBounds(180,280,150,40);//(kiri,atas,panjang,tinggi)
        btInsert.setBackground( new Color(111, 199, 180) );
        btInsert.setForeground(Color.white);
        btInsert.setBorder(null);
        btInsert.setOpaque(true);

        btUpdate.setBounds(20,280,150,40);
        btUpdate.setBackground( new Color(111, 199, 180) );
        btUpdate.setForeground(Color.white);
        btUpdate.setBorder(null);
        btUpdate.setOpaque(true);

        btViewAll.setBounds(400,280,150,40);
        btViewAll.setBackground( new Color(111, 199, 180) );
        btViewAll.setForeground(Color.white);
        btViewAll.setBorder(null);
        btViewAll.setOpaque(true);

        btAnalysis.setBounds(560,280,170,40);
        btAnalysis.setBackground( new Color(111, 199, 180) );
        btAnalysis.setForeground(Color.white);
        btAnalysis.setBorder(null);
        btAnalysis.setOpaque(true);

        btSaveTextFile.setBounds(560,230,170,40);
        btSaveTextFile.setBackground( new Color(111, 199, 180) );
        btSaveTextFile.setForeground(Color.white);
        btSaveTextFile.setBorder(null);
        btSaveTextFile.setOpaque(true);


        btDelete.setBounds(400,230,150,40);
        btDelete.setBackground( new Color(255, 77, 77) );
        btDelete.setForeground(Color.white);
        btDelete.setBorder(null);
        btDelete.setOpaque(true);

        btSortAsc.setBounds(400,180,150,40);
        btSortAsc.setBackground( new Color(111, 199, 180) );
        btSortAsc.setForeground(Color.white);
        btSortAsc.setBorder(null);
        btSortAsc.setOpaque(true);

        btSortDsc.setBounds(560,180,170,40);
        btSortDsc.setBackground( new Color(111, 199, 180) );
        btSortDsc.setForeground(Color.white);
        btSortDsc.setBorder(null);
        btSortDsc.setOpaque(true);

        btSearchName.setBounds(750,280,100,40);
        btSearchName.setBackground( new Color(111, 199, 180) );
        btSearchName.setForeground(Color.white);
        btSearchName.setBorder(null);
        btSearchName.setOpaque(true);

        btSearchCode.setBounds(860,280,100,40);
        btSearchCode.setBackground( new Color(111, 199, 180) );
        btSearchCode.setForeground(Color.white);
        btSearchCode.setBorder(null);
        btSearchCode.setOpaque(true);

        tfSearch.setBounds(750,230,210,40);
        tfSearch.setBackground(Color.white );
        tfSearch.setForeground(Color.black);
        tfSearch.setOpaque(true);

        lbName.setBounds(25,140,310,40);
        tfName.setBounds(20,170,310,40);
        tfName.setBackground(Color.white );
        tfName.setForeground(Color.black);
        tfName.setOpaque(true);

        lbCode.setBounds(25,200,150,40);
        tfCode.setBounds(20,230,150,40);
        tfCode.setBackground(Color.white );
        tfCode.setForeground(Color.black);
        tfCode.setOpaque(true);

        lbQuantity.setBounds(180,200,150,40);
        tfQuantity.setBounds(180,230,150,40);
        tfQuantity.setBackground(Color.white );
        tfQuantity.setForeground(Color.black);
        tfQuantity.setOpaque(true);

        lbReference.setBounds(20,50,310,100);
        lbReference.setBackground(Color.white );
        lbReference.setForeground(Color.black);
        lbReference.setOpaque(true);

        lbTitle.setBounds(100,10,810,50);
        lbTitle.setFont(new Font("Calibri", Font.BOLD, 30));
        lbDescription.setBounds(400,30,810,50);

        frame.add(lbTitle);
        frame.add(lbDescription);
        frame.add(lbName);
        frame.add(tfName);
        frame.add(lbCode);
        frame.add(tfCode);
        frame.add(lbQuantity);
        frame.add(tfQuantity);
        frame.add(btInsert);
        frame.add(btUpdate);
        frame.add(btViewAll);
        frame.add(lbReference);
        frame.add(btSearchName);
        frame.add(btSearchCode);
        frame.add(tfSearch);
        frame.add(btDelete);
        frame.add(btSortAsc);
        frame.add(btSortDsc);
        frame.add(btAnalysis);
        frame.add(btSaveTextFile);

        output.setBounds(20,340,960,330);
        output.setVerticalAlignment(JLabel.TOP);
        output.setBackground(Color.white );
        output.setForeground(Color.black);
        output.setOpaque(true);
        frame.add(output);

        btSaveTextFile.addActionListener(this);
        btAnalysis.addActionListener(this);
        btSortDsc.addActionListener(this);
        btSortAsc.addActionListener(this);
        btDelete.addActionListener(this);
        btSearchCode.addActionListener(this);
        btSearchName.addActionListener(this);
        btViewAll.addActionListener(this);
        btInsert.addActionListener(this);
        btUpdate.addActionListener(this);
        btSaveTextFile.addActionListener(this);
    }

    LinkedList linkedlist=new LinkedList();
    Summary view;
    public void actionPerformed(ActionEvent e)
    {
        Object source = e.getSource();
        if(source == btInsert)
        {
            Customer masker=new Masker(tfName.getText().toUpperCase(),tfCode.getText().toUpperCase(),Integer.parseInt(tfQuantity.getText().toUpperCase()));
            linkedlist.addLast(masker);
            view=new Summary(linkedlist);
            output.setText("<html>TOTAL NEED TO PAY BY "+tfName.getText().toUpperCase()+" RM"+String.format("%.2f", view.CalculateAllPaymentByName(tfName.getText()))+"<br><br>"+view.FindByName(tfName.getText())+"</html>");
        } 
        else if(source == btViewAll){
            output.setText("<html>"+view.FindAll()+"</html>");
        }
        else if(source == btSearchName){
            output.setText("<html>TOTAL PAYMENT BY "+tfSearch.getText().toUpperCase()+" RM"+String.format("%.2f", view.CalculateAllPaymentByName(tfSearch.getText()))+"<br><br>"+view.FindByName(tfSearch.getText())+"</html>");
        }
        else if(source == btSearchCode){
            output.setText("<html>TOTAL RECEIVED FOR MASKER CODE "+tfSearch.getText().toUpperCase()+" RM"+String.format("%.2f", view.CalculateAllPaymentMaskerCode(tfSearch.getText()))+"<br><br>"+view.FindByMaskerCode(tfSearch.getText())+"</html>");
        }
        else if(source == btUpdate){
            JFrame f =new JFrame();  
            Customer masker; masker=new Masker(tfName.getText().toUpperCase(),tfCode.getText().toUpperCase(),Integer.parseInt(tfQuantity.getText().toUpperCase()));
            String index=JOptionPane.showInputDialog(f,"Enter index");  
            view.UpdateList(Integer.parseInt(index),masker);
            output.setText("<html>RECORD UPDATE SUCCESSFUl<br><br>"+view.FindAll()+"</html>");
        }
        else if(source == btDelete){
            JFrame f =new JFrame();  
            String index=JOptionPane.showInputDialog(f,"PLEASE ENTER INDEX FROM VIEW RECORD");  
            view.RemoveByIndex(Integer.parseInt(index));
            output.setText("<html>"+view.FindAll()+"</html>");
        }
        else if(source == btSortAsc){
            output.setText("<html>Sort By Masker Price :<br>"+view.SortByMaskerPriceAscending()+"<br>Sort By Customer Name:<br>"+view.SortByCustomerNameAscending()+"</html>");
        }
        else if(source == btSortDsc){
            output.setText("<html>Sort By Masker Price :<br>"+view.SortByMaskerPriceDescending()+"<br>Sort By Customer Name:<br>"+view.SortByCustomerNameDescending()+"</html>");
        }
        else if(source == btAnalysis){
            output.setText("<html>ANALYSIS :<br>"+view.TotalPriceAndAverage()+view.MaskerSoldByCategory()+"<br><br>LOWEST QUANTITY PURCHASE BY CUSTOMER :<br>"+view.FindLowest()+"<br>HIGHEST QUANTITY PURCHASE BY CUSTOMER :<br>"+view.FindHighest()+"</html>");
        }
        else if(source == btSaveTextFile){
            view.ClassificationByCategory();
            output.setText("Data Saved into text files");
        }
    } 
}

public class MaskerApp {
    public static void main()
    {
        new MaskerMenu();
    }
}