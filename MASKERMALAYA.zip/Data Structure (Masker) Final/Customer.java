import java.io.BufferedReader;
import java.io.FileReader;
import java.util.StringTokenizer;
import java.io.IOException;

abstract class Customer
{
    String name;
    boolean membership;

    Customer(String name){
        this.name=name;
    }

    //accessor
    public String getName(){return name;}

    //mutator
    public void setName(String o){name=o;}

    //this function will read from notepad membership and get the name to identofy the name is in the list of membership
    private void ReadFromTextFiles(){
        try {
            BufferedReader read = new BufferedReader(new FileReader("Membership.txt"));
            String data = read.readLine();
            while(data != null){
                StringTokenizer m = new StringTokenizer(data, ";");
                String cName=m.nextToken();
                if(name.equalsIgnoreCase(cName))
                {
                    this.membership=true;
                } 
                data = read.readLine();
            }
            read.close();
        }catch (IOException err) {
            System.err.print(err);
        }
    }

    // get membership status will return true or falase from function readfromtextfile
    public boolean membership(){
        this.ReadFromTextFiles();
        return membership;
    }

    //output for this class will return this item
    public String toString() {
        return "NAME :"+name;
    }
}
