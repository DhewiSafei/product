
public class LinkedList
{
    private Node head;
    private Node tail ;
    private Node current;
    private String name;

    private int count;

    LinkedList(){
        this("linked list");
    }

    // get the size from linkedlist based on count 
    public int size()
    {
        return count;
    }

    LinkedList(String s){
        head=tail=current = null;
    }

    //check the linkedlist is empty or not
    public boolean isEmpty(){ 
        return head == null;
    }

    //get first object from linkedlist 
    public Node getFirstNode() {
        return head;
    }

    // get next object from linkedlist
    public Node getNext(Node o) {
        return o.next;
    }

    // get last object from linkedlist
    public Node getLastNode() {
        return tail;
    }

    // this function will add object in the last of the list
    public void addLast(Object elem){
        count++;
        if(isEmpty())
        {
            head=tail=new Node(elem);
        }
        else{
            tail=tail.next=new Node(elem);
        }
    }

    // this function will add object in the begining of the list
    public void addFirst(Object elem){
        count++;
        if(isEmpty())
        {
            head=tail=new Node(elem);
        }
        else{
            head=new Node(elem,head);
        }
    }
    
    //this function will get the first object from the list
    public Object getFirst(){
        if(isEmpty())
            return null;
        else{
            current=head;
            return current.data;
        }
    }

    //this function will get last object from the list
    public Object getLast() {

        if (isEmpty()) {
            return null;
        }
        else {
            return tail.data;
        }
    }

    //this function will get next object from the list
    public Object getNext(){
        if(current!=tail)
        {
            current=current.next;
            return current.data;
        }
        else 
            return null;
    }

    //this function will delete object from the list
    public Object removeLast() throws EmptyListException{        
        count--;
        Object removeItem=null;

        if(isEmpty())
            throw new EmptyListException(name);

        removeItem=tail.data;
        if(head.equals(tail))
        {head=tail=null;}
        else
        {
            Node current =head;
            while(current.next!=tail)
                current=current.next;
            tail=current;
            current.next=null;
        }

        return removeItem;
    }

    //this function will delete object for index 0 from the list
    public Object removeFirst() throws EmptyListException{
        Object removeItem=null; 
        count--;
        if(isEmpty())
            throw new EmptyListException(name);

        removeItem=head.data;
        if(head.equals(tail))
        {head=tail=null;}
        else
            head=head.next;

        return removeItem;
    }

    //this function will delete object based on index from the list
    public void remove(int i) {
        if (i < 0 || i >= size()) {
            return;
        }
        if (i == 0) {
            if (head == tail) {
                head = tail = null;
            } else {
                head = head.next;
            }
        } else {
            Node runner = head;
            Node previous = null;
            while (i > 0) {
                previous = runner;
                runner = runner.getNext();
                i--;
            }
            previous.setNext(runner.getNext());
            if (runner == tail) {
                tail = previous;
            }
        }
        count--;
    }

    //this function will replace object from the list based on index
    public void set(int index, Object dat) {
        Node current=head;
        for(int i=0; i<index; i++)
        {
            current = current.next;
        }  
        current.data=dat;
    }  

    // this function will get object from list based on index
    public Object get(int index) {
        Node temp=head;
        for(int i=0; i<index; i++)
        {
            temp = temp.next;
        }
        return temp.data;
    }

    //Using bubble sort algorithm this is how sort the object in the list by by price in ascending and descending
    public void SortByPriceAscending()
    {
        Node current = head, mTemp = null;
        Object temp;
        if (head == null) {
            return;
        }
        else {
            while (current != null) {
                mTemp = current.next;
                while (mTemp != null) {
                    if (((Masker)current.data).Price() > ((Masker)mTemp.data).Price()) {
                        temp = current.data;
                        current.data = mTemp.data;
                        mTemp.data = temp;
                    }
                    mTemp = mTemp.next;
                }
                current = current.next;
            }
        }
    }

    public void SortByPriceDescending()
    {
        Node current = head, mTemp = null;
        Object temp;
        if (head == null) {
            return;
        }
        else {
            while (current != null) {
                mTemp = current.next;
                while (mTemp != null) {
                    if (((Masker)current.data).Price() < ((Masker)mTemp.data).Price()) {
                        temp = current.data;
                        current.data = mTemp.data;
                        mTemp.data = temp;
                    }
                    mTemp = mTemp.next;
                }
                current = current.next;
            }
        }
    }

    //Using bubble sort algorithm this is how sort the object in the list by by name in ascending and descending
    public void SortByCustomerNameAscending()
    {
        Node current = head, mTemp = null;
        Object temp;
        if (head == null) {
            return;
        }
        else {
            while (current != null) {
                mTemp = current.next;
                while (mTemp != null) {
                    if (((Masker)current.data).getName().compareTo(((Masker)mTemp.data).getName())>0) {
                        temp = current.data;
                        current.data = mTemp.data;
                        mTemp.data = temp;
                    }
                    mTemp = mTemp.next;
                }
                current = current.next;
            }
        }
    }

    public void SortByCustomerNameDescending()
    {
        Node current = head, mTemp = null;
        Object temp;
        if (head == null) {
            return;
        }
        else {
            while (current != null) {
                mTemp = current.next;
                while (mTemp != null) {
                    if (((Masker)current.data).getName().compareTo(((Masker)mTemp.data).getName())<0) {
                        temp = current.data;
                        current.data = mTemp.data;
                        mTemp.data = temp;
                    }
                    mTemp = mTemp.next;
                }
                current = current.next;
            }
        }
    }

    
    // this function is to get the minimum quantity sold for masker in the list
    public Object MinimumQuantity() {
        Node current = head;
        double min = ((Masker)current.data).getmaskerQuantity();
        Object data=null;
        
        while(current != null){
            if(min >=((Masker)current.data).getmaskerQuantity()){
                min = ((Masker)current.data).getmaskerQuantity();
                data=current.data;
            }
            current = current.next;
        }
        return data;
    }
    
    // this function is to get the maximum quantity sold for masker in the list
     public Object MaximumQuantity() {
        Node current = head;
        double max = 0;
        Object data=null;
        
        while(current != null){
            if(max <=((Masker)current.data).getmaskerQuantity()){
                max = ((Masker)current.data).getmaskerQuantity();
                data=current.data;
            }
            current = current.next;
        }
        return data;
    }
    
    //this function is to count total masker sold from the list
    public int CountMaskerSold(String Code) {
        Node current = head;
        int countMasker=0;
        while(current != null){
            if(((Masker)current.data).getMaskerCode().equalsIgnoreCase(Code)){
                countMasker+=((Masker)current.data).getmaskerQuantity();
            }
            current = current.next;
        }
        return countMasker++;
    }

    
}

